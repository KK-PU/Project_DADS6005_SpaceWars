#import library
import pymongo
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import dash
from dash import Input, Output, dcc, html, dash_table, Dash 
import plotly.graph_objs as go
import plotly.express as px
import dash_bootstrap_components as dbc

#import css
sns.set_style("dark")
external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(external_stylesheets=[dbc.themes.BOOTSTRAP])

# Connect to MongoDB
#client = pymongo.MongoClient("mongodb://localhost:27017")
client = pymongo.MongoClient("mongodb+srv://paanthkt:bze44Wn5OfLNC7pY@cluster0.kmel07d.mongodb.net/")
db = client.Quiz3
collection = db.spacewar

data = list(collection.find())

# Create DataFrame
df = pd.DataFrame(data, columns=["A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "A10","A11"])

print(data)
print(df)
